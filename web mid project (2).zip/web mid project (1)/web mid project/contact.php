<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = ""; // Default XAMPP password is empty
$dbname = "your_database_name"; // Replace with your database name

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$name = $_POST['name'];
$email = $_POST['email'];
$product = $_POST['product'];
$color = $_POST['color'];
$material = $_POST['material'];
$address = $_POST['address'];
$message = $_POST['message'];

// Insert form data into the database
$sql = "INSERT INTO orders (name, email, product, color, material, address, message) VALUES ('$name', '$email', '$product', '$color', '$material', '$address', '$message')";

if ($conn->query($sql) === TRUE) {
    echo "Order placed successfully! We will contact you shortly.";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close connection
$conn->close();
?>
